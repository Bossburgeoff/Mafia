PRAGMA foreign_keys = ON;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS players (
    player_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nickname TEXT NOT NULL CHECK(length(trim(nickname)) BETWEEN 2 AND 24),
    email TEXT,
    registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive','blocked'))
);
CREATE TABLE IF NOT EXISTS rooms (
    room_id INTEGER PRIMARY KEY AUTOINCREMENT,
    invite_code TEXT NOT NULL UNIQUE CHECK(length(invite_code) BETWEEN 4 AND 12),
    owner_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status TEXT NOT NULL DEFAULT 'waiting' CHECK(status IN ('waiting','running','finished','closed')),
    max_players INTEGER NOT NULL DEFAULT 10 CHECK(max_players BETWEEN 4 AND 20),
    FOREIGN KEY(owner_id) REFERENCES players(player_id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS room_members (
    room_id INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    member_status TEXT NOT NULL DEFAULT 'connected' CHECK(member_status IN ('connected','disconnected','left')),
    PRIMARY KEY(room_id, player_id),
    FOREIGN KEY(room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(player_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS games (
    game_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL,
    started_at TEXT,
    finished_at TEXT,
    phase TEXT NOT NULL DEFAULT 'waiting' CHECK(phase IN ('waiting','night','day','voting','finished')),
    result TEXT,
    FOREIGN KEY(room_id) REFERENCES rooms(room_id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS roles (
    role_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    team TEXT NOT NULL CHECK(team IN ('mafia','town','neutral')),
    action_type TEXT NOT NULL DEFAULT 'none',
    description TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS game_participants (
    game_id INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    state TEXT NOT NULL DEFAULT 'alive' CHECK(state IN ('alive','eliminated','disconnected')),
    seat_no INTEGER NOT NULL CHECK(seat_no BETWEEN 1 AND 20),
    PRIMARY KEY(game_id, player_id),
    UNIQUE(game_id, seat_no),
    FOREIGN KEY(game_id) REFERENCES games(game_id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(player_id) ON DELETE RESTRICT,
    FOREIGN KEY(role_id) REFERENCES roles(role_id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS votes (
    vote_id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id INTEGER NOT NULL,
    voter_id INTEGER NOT NULL,
    target_id INTEGER,
    round_no INTEGER NOT NULL CHECK(round_no >= 1),
    choice_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(game_id) REFERENCES games(game_id) ON DELETE CASCADE,
    FOREIGN KEY(voter_id) REFERENCES players(player_id) ON DELETE RESTRICT,
    FOREIGN KEY(target_id) REFERENCES players(player_id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    game_id INTEGER NOT NULL,
    actor_id INTEGER,
    event_type TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(game_id) REFERENCES games(game_id) ON DELETE CASCADE,
    FOREIGN KEY(actor_id) REFERENCES players(player_id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS messages (
    message_id INTEGER PRIMARY KEY AUTOINCREMENT,
    room_id INTEGER NOT NULL,
    player_id INTEGER NOT NULL,
    text TEXT NOT NULL CHECK(length(trim(text)) BETWEEN 1 AND 1000),
    sent_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(room_id) REFERENCES rooms(room_id) ON DELETE CASCADE,
    FOREIGN KEY(player_id) REFERENCES players(player_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_room_members_player ON room_members(player_id);
CREATE INDEX IF NOT EXISTS idx_games_room ON games(room_id);
CREATE INDEX IF NOT EXISTS idx_votes_game_round ON votes(game_id, round_no);
CREATE INDEX IF NOT EXISTS idx_events_game_time ON events(game_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_room_time ON messages(room_id, sent_at);
INSERT OR IGNORE INTO roles(name, team, action_type, description) VALUES
('Мирный житель','town','none','Участвует в обсуждении и дневном голосовании.'),
('Мафия','mafia','eliminate','Ночью выбирает цель совместно с командой мафии.'),
('Дон','mafia','investigate','Руководит мафией и может проверять игроков по правилам режима.'),
('Комиссар','town','investigate','Ночью проверяет выбранного игрока.'),
('Доктор','town','protect','Ночью выбирает игрока для защиты.'),
('Любовница','neutral','block','Ночью блокирует действие выбранного игрока согласно правилам режима.');
COMMIT;
